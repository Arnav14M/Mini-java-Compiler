import syntaxtree.*;
import visitor.*;

public class P4 {
   public static void main(String [] args) {
      try {
         Node root = new MiniIRParser(System.in).Goal();
	     ParseZero P0 = new ParseZero();
         ParseOne P1 = new ParseOne();
	     root.accept(P0);
         P1.maxx = P0.maxx;
         root.accept(P1);
      }
      catch (ParseException e) {
         System.out.println(e.toString());
      }
   }
} 



