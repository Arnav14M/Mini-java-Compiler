import syntaxtree.*;
import visitor.*;
import java.util.*;

class Temporary {
    public String name;
    public Integer start;
    public Integer end;
    public String location;
    public Integer reg;
    Temporary(String t,Integer s, Integer e){
        start=s;end=e;name=t;
    }
    
}

public class P5 {
   
   public static void main(String [] args) {
      
      try {
         HashMap<String, Integer> numargs = new HashMap<String, Integer>();
         HashMap<String, Integer> basestack = new HashMap<String, Integer>();
         HashMap<String, Integer> maxcallargs = new HashMap<String, Integer>();
         HashMap<String, HashMap<String, HashMap<String, HashSet<String> > > > LivenessTable = new HashMap<String, HashMap<String, HashMap<String, HashSet<String> > > >();
         HashMap<String, HashMap<String, Integer> > LiveStart = new HashMap<String, HashMap<String, Integer>>();
         HashMap<String, HashMap<String, Integer> > LiveEnd = new HashMap<String, HashMap<String, Integer>>();
         HashMap<String, Integer> procSpills = new HashMap<String, Integer>();
         Node root = new microIRParser(System.in).Goal();
         ParseZero P0 = new ParseZero();
         root.accept(P0);
         ParseOne P1 = new ParseOne();
         P1.labellines = P0.labellines;
         int c=1;root.accept(P1);P1.repeat=0;
         while(P1.repeat==0){
         P1.repeat=1;
         root.accept(P1);
         c++;}
         //System.out.println(c+"");
         LivenessTable = P1.Liveness;
         //System.out.println(LivenessTable.get("MAIN").get("in").toString()+"\n"+c);System.out.println(LivenessTable.get("MAIN").get("out").toString()+"\n"+c);

         //LIVEEND
         for(String proc : LivenessTable.keySet()){
            LiveEnd.put(proc,new HashMap<String,Integer>());
            for(String node : LivenessTable.get(proc).get("out").keySet()){
               Integer nodenum = Integer.parseInt(node);
               HashSet<String> sub = new HashSet<String>();sub.addAll( LivenessTable.get(proc).get("out").get(node) );
               sub.addAll( LivenessTable.get(proc).get("def").get(node) );
               for(String var : sub ){
                  //if(!LiveStart.get(proc).containsKey(var)) LiveStart.get(proc).put(var,nodenum);
                  if(!LiveEnd.get(proc).containsKey(var)) LiveEnd.get(proc).put(var,nodenum);
                  //if(LiveStart.get(proc).get(var)>nodenum) LiveStart.get(proc).put(var,nodenum);
                  if(LiveEnd.get(proc).get(var)<nodenum) LiveEnd.get(proc).put(var,nodenum);
               }
            }
         }
         //LIVESTART
         for(String proc : LivenessTable.keySet()){
            LiveStart.put(proc,new HashMap<String,Integer>());
            for(String node : LivenessTable.get(proc).get("in").keySet()){
               Integer nodenum = Integer.parseInt(node);
               HashSet<String> sub = new HashSet<String>();sub.addAll( LivenessTable.get(proc).get("in").get(node) );
               sub.addAll( LivenessTable.get(proc).get("def").get(node) );
               for(String var : sub ){
                  if(!LiveStart.get(proc).containsKey(var)) LiveStart.get(proc).put(var,nodenum);
                  //if(!LiveEnd.get(proc).containsKey(var)) LiveEnd.get(proc).put(var,nodenum);
                  if(LiveStart.get(proc).get(var)>nodenum) LiveStart.get(proc).put(var,nodenum);
                  //if(LiveEnd.get(proc).get(var)<nodenum) LiveEnd.get(proc).put(var,nodenum);
               }
            }
         }
         

         HashMap<String,List<Temporary> > tempobs = new HashMap<String,List<Temporary> > ();
         for(String proc : LiveStart.keySet()){
            tempobs.put(proc,new ArrayList<Temporary> ());
            for(String x : LiveStart.get(proc).keySet()){
               if(LiveEnd.get(proc).get(x)==null) LiveEnd.get(proc).put( x , LiveStart.get(proc).get(x) );
               tempobs.get(proc).add(new Temporary(x,LiveStart.get(proc).get(x),LiveEnd.get(proc).get(x)));
            }
         }

         HashMap<String,HashMap<String,Temporary> > alldata = new HashMap<String,HashMap<String,Temporary> >();
         String[] regs = new String[] {"s0","s1","s2","s3","s4","s5","s6","s7","t0","t1","t2","t3","t4","t5","t6","t7","t8","t9"};
         for(String proc : tempobs.keySet()){
             alldata.put(proc,new HashMap<String,Temporary>());
             Integer[] inuse = new Integer[] {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
             List<Temporary> startasc = new ArrayList<Temporary> (); startasc.addAll(tempobs.get(proc));
             Collections.sort(startasc, (Temporary t1,Temporary t2) -> t1.start-t2.start );
             //List<Temporary> endasc = new ArrayList<Temporary> (); endasc.addAll(tempobs.get(proc));
             //Collections.sort(endasc, (Temporary t1,Temporary t2) -> t1.end-t2.end );
             //for(Temporary t : endasc) System.out.println(t.name+" "+t.end);
             List<Temporary> active = new ArrayList<Temporary> ();
             Integer spillc=0;
             for(Temporary tnode : startasc){
               Integer i=tnode.start;
               //for(Temporary fff :active) System.out.println(fff.start);
               active.removeIf(x -> x.end<i);
               for(int gg=0;gg<18;gg++)inuse[gg]=0;
               for(Temporary x : active) inuse[alldata.get(proc).get(x.name).reg]=1;
               if(active.size()==18){
                  if(active.get(active.size()-1).end>tnode.end){
                     tnode.reg = active.get( active.size()-1 ).reg;tnode.location = active.get(active.size()-1).location;//setting parameters of tnode
                     alldata.get(proc).put(tnode.name,tnode);//putting tnode in alldata
                     alldata.get(proc).get(active.get(active.size()-1).name).reg=-1;alldata.get(proc).get(active.get(active.size()-1).name).location=""+spillc;spillc++;//respecing alldata for subbed node
                     active.remove(active.size()-1);//removing subbed guy
                     active.add(tnode);//adding tnode to active
                     Collections.sort(active, (Temporary t1,Temporary t2) -> t1.end-t2.end );//sorting active based on end
                  }
                  else{
                     tnode.reg = -1;tnode.location = ""+spillc;spillc++;//giving tnode stack location
                     alldata.get(proc).put(tnode.name,tnode);//putting tnode in alldata
                  }
               }
               else{
                    Integer k=0;
                    while(inuse[k].equals(1))k=k+1;
                    inuse[k]=1;
                    tnode.reg = k;tnode.location = regs[k];
                    alldata.get(proc).put(tnode.name,tnode);
                    active.add(tnode);
                    Collections.sort(active, (Temporary t1,Temporary t2) -> t1.end-t2.end );//sorting active based on end
               }
             }
             procSpills.put(proc,spillc);
         }

         

////////////////
         ParseTwo P2 = new ParseTwo();
         P2.procSpills = procSpills;
         //P2.alldata = alldata;
         root.accept(P2);
         numargs = P2.numargs;
         basestack = P2.basestack;
         maxcallargs = P2.maxcallargs;

         for(String proc : alldata.keySet()){
             for(String node : alldata.get(proc).keySet()){
                if(alldata.get(proc).get(node).reg.equals(-1)) {
                    //System.out.println(Integer.parseInt( alldata.get(proc).get(node).location ) + " " + basestack.get(proc));
                    alldata.get(proc).get(node).location = "" + ( Integer.parseInt( alldata.get(proc).get(node).location ) + basestack.get(proc) );
                }
             }  
             basestack.put(proc, basestack.get(proc) + procSpills.get(proc) );
         }
         HashMap<String,HashMap<String,String> > finalmap = new HashMap<String,HashMap<String,String> >();
         for(String proc : alldata.keySet()){
            finalmap.put(proc,new HashMap<String,String>());
            for(String var : alldata.get(proc).keySet()){
               finalmap.get(proc).put(var,alldata.get(proc).get(var).location);
            }
         }



         ParseThree P3 = new ParseThree();
         P3.basestack = basestack;
         P3.numargs = numargs;
         P3.finalmap = finalmap;
         P3.maxcallargs = maxcallargs;
         root.accept(P3);

         /*String ex = "QS_Print";
         for(String x : alldata.get(ex).keySet()){
            System.out.println(x+" "+LiveStart.get(ex).get(x)+" "+LiveEnd.get(ex).get(x)+" "+alldata.get(ex).get(x).reg+" "+alldata.get(ex).get(x).location);
         }
         //System.out.println(basestack+" "+numargs+"\n"+finalmap);*/
      }
      catch (ParseException e) {
         System.out.println(e.toString());
      }
   }
} 



