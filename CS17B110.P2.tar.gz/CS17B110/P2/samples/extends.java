class Extended {
    public static void main(String[] a) {
        System.out.println(new Class1().AMethod());
    }
}


class Class1 extends Class2{
int x;
    public int AMethod() {y=false;
        return 0;
    }

    public int BMethod() {
        return 1;
    }

    public int CMethod() {
        return 2;
    }
}

class Class2 extends Class1{
boolean y;
Class1 f;
    public int BMethod() {
	Class2 r;
	r = f;f=r;
        return 3;
    }

    public int DMethod() {
        return 4;
    }
}

