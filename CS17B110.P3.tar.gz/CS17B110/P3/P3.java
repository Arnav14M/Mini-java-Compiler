import syntaxtree.*;
import visitor.*;

public class P3 {
   public static void main(String [] args) {
      try {
         Node root = new MiniJavaParser(System.in).Goal();
         //System.out.println("Program parsed successfully");
         //root.accept(new GJNoArguDepthFirst()); // Your assignment part is invoked here.
         //HashMap<String, HashMap<String, HashMap<String, HashMap<String, String > > > > AllClasses;
         ParseOne P1 = new ParseOne();
	 ParseZero P0 = new ParseZero();
	 root.accept(P0);	
	 P1.AllClasses = P0.AllClasses;
	 P1.classders = P1.classders;
         root.accept(P1);
         
         IRP1 Pir = new IRP1();
         Pir.AllClasses=P1.AllClasses;
	     Pir.classfuns=P1.classfuns;
	     Pir.cvord=P1.cvord;
	Pir.pars=P1.pars;
         root.accept(Pir);
         
	 //P1.AllClasses = P0.AllClasses;
         //P1.classders = P0.classders;
         //root.accept(P1);
         //System.out.println(P1.AllClasses.toString());
         //ParseTwo P2 = new ParseTwo();
         //P2.AllClasses = P1.AllClasses;
         //P2.classders = P1.classders;
         //root.accept(P2); 
      }
      catch (ParseException e) {
         System.out.println(e.toString());
      }
   }
} 



